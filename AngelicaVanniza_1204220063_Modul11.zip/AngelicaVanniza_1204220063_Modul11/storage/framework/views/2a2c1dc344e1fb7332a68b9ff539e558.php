<div class="container mt-4">
    <h4><?php echo e($pageTitle); ?></h4>
    <hr>
    <div class="d-flex align-items-center py-2 px-4 bg-light rounded-3
    border">
    <div class="bi-house-fill me-3 fs-1"></div>
    <h4 class="mb-0">Well done! this is <?php echo e($pageTitle); ?>.</h4>
    </div
<?php /**PATH E:\Anugrah Putra Syifa Al Ghifari\Documents\ITTS\Mapel\Semester 4\FRAMEWORK\Praktikum\Praktikum 7\Tugas\laravel-auth\resources\views/default.blade.php ENDPATH**/ ?>